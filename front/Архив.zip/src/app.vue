<template>
  <div id="app">
    <h1 class="header-title">Обработка графа квантовым алгоритмом, РТУ МИРЭА команда "Краники"</h1>
    
    <LoadFiles />
    <FileView />
    <QuantVisualise />
  </div>
</template>

<script>
import LoadFiles from './components/load.vue'
import FileView from './components/file_view.vue'
import QuantVisualise from './components/quant_visualise.vue'

export default {
  name: 'App',
  components: {
    LoadFiles,
    FileView,
    QuantVisualise
  }
}
</script>

<style>
html, body {
  display: flex;
  justify-content: center;
  height: 50%;
  margin: 0;
  background-color: #202326;
  color: white;
}

#app {
  display: flex;
  flex-direction: column;
  justify-content: center;
  align-items: center;
  width: 100%;
  max-width: 600px;
  font-family: Avenir, Helvetica, Arial, sans-serif;
  -webkit-font-smoothing: antialiased;
  -moz-osx-font-smoothing: grayscale;
  text-align: center;
  margin-top: 60px;
  padding: 20px;
  border-radius: 10px; 
}

.header-title {
  font-size: 24px;
  font-weight: bold;
  color: white;
  margin-bottom: 20px;
  background-color: #333;
  padding: 15px 30px;
  border-radius: 10px;
  width: 100%;
  box-sizing: border-box;
}

.button-container {
  display: flex;
  justify-content: center;
  width: 100%;
  gap: 20px;
  background-color: #333;
  padding: 15px;
  border-radius: 10px;
  box-sizing: border-box;
}

.load-btn {
  background-color: #007bff;
  color: white;
  border: none;
  padding: 12px 24px;
  font-size: 16px;
  border-radius: 12px;
  cursor: pointer;
  transition: background-color 0.3s ease;
  width: 48%;
}

.load-btn:hover {
  background-color: #0056b3;
}
</style>

