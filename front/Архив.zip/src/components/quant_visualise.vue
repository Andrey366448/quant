<template>
  <div class="quant-container">
    <h2>Квантовая визуализация</h2>

    <!-- КНОПКИ ЗАПУСКА АЛГОРИТМОВ -->
    <div class="button-row">
      <button
        class="action-btn"
        :disabled="loadingInspired"
        @click="runQuantInspired"
      >
        {{ loadingInspired ? 'Запуск...' : 'Квант-вдохновлённый' }}
      </button>

      <button
        class="action-btn"
        :disabled="loadingFull"
        @click="runQuantFull"
      >
        {{ loadingFull ? 'Запуск...' : 'Полный квантовый' }}
      </button>
    </div>

    <p v-if="message" class="message">{{ message }}</p>
    <p v-if="error" class="error">{{ error }}</p>

    <!-- ГАЛЕРЕЯ PNG ИЗ visualised_gi -->
    <div class="gallery-container">
      <button class="btn" @click="toggleList">
        {{ showList ? 'Скрыть визуализации' : 'Показать визуализации' }}
      </button>

      <div v-if="showList" class="content">
        <div class="list">
          <div class="list-title">Файлы (PNG)</div>
          <ul class="files">
            <li
              v-for="(f, idx) in files"
              :key="idx"
              :class="{ active: f === selected }"
              @click="select(f)"
              title="Открыть превью"
            >
              {{ f }}
            </li>
            <li v-if="files.length === 0" class="empty">Пока пусто</li>
          </ul>
          <button class="btn secondary" @click="refresh" :disabled="loadingList">
            {{ loadingList ? 'Обновляю...' : 'Обновить список' }}
          </button>
        </div>

        <div class="preview" v-if="selected">
          <div class="preview-title">{{ selected }}</div>
          <img :src="imageUrl(selected)" alt="preview" class="img" @error="onImgError" />
        </div>
        <div class="preview placeholder" v-else>
          Выберите файл слева
        </div>
      </div>
    </div>
  </div>
</template>

<script>
import axios from "axios";

export default {
  name: "QuantVisualise",
  data() {
    return {
      // запуск алгоритмов
      loadingInspired: false,
      loadingFull: false,
      message: "",
      error: "",

      // галерея
      showList: false,
      files: [],
      selected: "",
      loadingList: false,
      baseListUrl: "http://127.0.0.1:8000/visualised_qi/",
      baseImgUrl: "http://127.0.0.1:8000/static/visualised_qi/",
    };
  },
  methods: {
    // ===== запуск алгоритмов =====
    async runQuantInspired() {
      this.message = "";
      this.error = "";
      this.loadingInspired = true;
      try {
        const res = await axios.post("http://127.0.0.1:8000/quant_inspired/");
        this.message = res.data?.message ?? "Готово.";
      } catch (e) {
        console.error(e);
        this.error = "Ошибка при запуске квант-вдохновлённого алгоритма.";
      } finally {
        this.loadingInspired = false;
      }
    },
    async runQuantFull() {
      this.message = "";
      this.error = "";
      this.loadingFull = true;
      try {
        const res = await axios.post("http://127.0.0.1:8000/quant_full/");
        this.message = res.data?.message ?? "Готово.";
      } catch (e) {
        console.error(e);
        this.error = "Ошибка при запуске полного квантового алгоритма.";
      } finally {
        this.loadingFull = false;
      }
    },

    // ===== галерея PNG =====1
    toggleList() {
      this.showList = !this.showList;
      if (this.showList && this.files.length === 0) this.refresh();
    },
    async refresh() {
      this.loadingList = true;
      try {
        const { data } = await axios.get(this.baseListUrl);
        this.files = data.files || [];
        if (!this.files.includes(this.selected)) this.selected = "";
      } catch (e) {
        console.error("Не удалось получить список PNG:", e);
        alert("Ошибка при получении списка изображений.");
      } finally {
        this.loadingList = false;
      }
      
    },
    select(f) {
      this.selected = f;
    },
    imageUrl(filename) {
      // cache-busting, чтобы видеть свежую картинку
      return `${this.baseImgUrl}${encodeURIComponent(filename)}?t=${Date.now()}`;
    },
    onImgError() {
      alert("Не удалось загрузить изображение. Проверьте, что файл существует.");
    },
  },
};
</script>

<style scoped>
.quant-container {
  width: 100%;
  max-width: 720px;
  background-color: #333;
  color: #fff;
  padding: 20px;
  margin-top: 20px;
  border-radius: 14px;
  box-shadow: 0 8px 24px rgba(0, 0, 0, 0.35);
}

h2 {
  margin: 0 0 14px 0;
  font-weight: 700;
}

.button-row {
  display: flex;
  gap: 12px;
  flex-wrap: wrap;
  margin: 10px 0 6px;
}

.action-btn {
  background-color: #007bff;
  color: #fff;
  border: none;
  padding: 12px 18px;
  font-size: 16px;
  border-radius: 12px;
  cursor: pointer;
  transition: transform 0.05s ease, background-color 0.2s ease, opacity 0.2s ease;
}

.action-btn:hover {
  background-color: #005ed1;
}

.action-btn:disabled {
  opacity: 0.6;
  cursor: default;
}

.message {
  margin-top: 10px;
  color: #cfe8ff;
}

.error {
  margin-top: 10px;
  color: #ffb3b3;
}
</style>
