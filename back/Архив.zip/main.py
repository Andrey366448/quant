# back/main.py
from fastapi import FastAPI, UploadFile, File, HTTPException
from fastapi.middleware.cors import CORSMiddleware
import shutil
import quantum_inspired
import os
from pathlib import Path
from fastapi import FastAPI, HTTPException
from fastapi.responses import FileResponse
from starlette.staticfiles import StaticFiles

app = FastAPI()

app.add_middleware(
    CORSMiddleware,
    allow_origins=["*"],  # Разрешаем запросы с любых источников
    allow_credentials=True,
    allow_methods=["*"],  # Разрешаем все HTTP методы
    allow_headers=["*"],  # Разрешаем все заголовки
)

# Папка для хранения загруженных файлов
BASE_DIR = Path(__file__).resolve().parent
UPLOAD_FOLDER = "uploads"
SERVER_FOLDER = "server"
VIS_FOLDER = "visualised_qi"
VIS_DIR = BASE_DIR / "visualised_qi"
os.makedirs(VIS_FOLDER, exist_ok=True)
os.makedirs(UPLOAD_FOLDER, exist_ok=True)
os.makedirs(SERVER_FOLDER, exist_ok=True)

app.mount("/static/visualised_qi", StaticFiles(directory=str(VIS_FOLDER)), name="visgi")

@app.get("/upload/")
async def get_files():
    """
    Возвращает список всех файлов в папке.
    """
    files = os.listdir(UPLOAD_FOLDER)
    return {"files": files}

@app.post("/upload/")
async def upload_file(file: UploadFile = File(...)):
    """
    Загружает файл на сервер. Если файл zip, распаковывает его.
    """

    # Сохраняем файл во временной директории
    temp_file_path = os.path.join(UPLOAD_FOLDER, file.filename)
    with open(temp_file_path, "wb") as f:
        f.write(await file.read())

    # Проверяем, если это zip файл
    if file.filename.endswith('.zip'):
        try:
            # Распаковываем архив
            shutil.unpack_archive(temp_file_path, UPLOAD_FOLDER)
            os.remove(temp_file_path)  # Удаляем исходный архив после распаковки
            return {"message": f"File {file.filename} successfully uploaded and unpacked."}
        except shutil.ReadError:
            raise HTTPException(status_code=400, detail="Failed to unpack archive. It may be corrupted.")
    else:
        # Если это не zip файл, просто возвращаем его имя
        return {"filename": file.filename}


@app.delete("/upload/clear/")
async def clear_upload_folder():
    files = os.listdir(UPLOAD_FOLDER)

    for filename in files:
        file_path = os.path.join(UPLOAD_FOLDER, filename)
        if os.path.isfile(file_path):
            os.remove(file_path)

    return {"message": "Файлы были очищенны"}

@app.get("/download/")
async def download_files():
    # Создаем архив с файлами
    archive_path = "uploads.zip"
    shutil.make_archive(archive_path.replace(".zip", ""), 'zip', UPLOAD_FOLDER)

    # Отправляем архив пользователю
    return FileResponse(archive_path, media_type='application/zip', filename="uploads.zip")

@app.post("/upload/fromserver")
async def upload_from_server():
    """
    Загружает файлы с сервера.
    """

    for filename in os.listdir(SERVER_FOLDER):
        src_file = os.path.join(SERVER_FOLDER, filename)
        dst_file = os.path.join(UPLOAD_FOLDER, filename)

        if os.path.isfile(src_file):
            shutil.copy(src_file, dst_file)  # Копируем файл

    return {"message": "Файлы были загружены с сервера"}

@app.post("/quant_inspired/")
async def quant_inspired():
    quantum_inspired.main()
    return {"message": "Квантово-вдохновлённый алгоритм завершил работу"};

@app.post("/quant_full/")
async def quant_full():
    quantum_inspired.main()
    return {"message": "Квантовый алгоритм завершил работу"};

@app.get("/visualised_qi/")
async def list_visualised_pngs():
    files = sorted([p.name for p in VIS_DIR.iterdir() if p.is_file() and p.suffix.lower()==".png"])
    # удобно сразу вернуть готовые URL
    return {"files": files, "urls": [f"/static/visualised_qi/{name}" for name in files]}

@app.get("/visualised_qi/{filename}")
async def get_visualised_png(filename: str):
    path = VIS_FOLDER / filename
    if not (path.is_file() and path.suffix.lower() == ".png"):
        raise HTTPException(status_code=404, detail="Image not found")
    return FileResponse(str(path), media_type="image/png", filename=filename)